/*
* Ejercicios básicos java con estructura iterativa o repetitiva
* Mostrar los números del 100 al 1 utilizando un bucle for
*/
public class Repetitiva1_6 {
    public static void main(String[] args) {
    System.out.println("Numeros del 100 al 1: ");
    for(int i=100;i>=1;i--)
    System.out.println(i);
    }
    }