public class ejercico1 {
    /*
* Ejercicios básicos java con estructura iterativa o repetitiva
* Mostrar los números del 1 al 100
* utilizando un bucle while
*/
public class Main {
    public static void main(String[] args) {
    System.out.println("Numeros del 1 al 100: ");
    int i=1;
    while(i<=100) {
    System.out.println(i);
    i++;
    }
    }
    }
}
