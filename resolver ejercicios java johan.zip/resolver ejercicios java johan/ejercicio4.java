public class ejercicio4 {
   /*
* Ejercicios básicos java con estructura iterativa o repetitiva
* Mostrar los números del 100 al 1 utilizando un bucle while
*/
public class Main {
    public static void main(String[] args) {
    System.out.println("Numeros del 100 al 1: ");
    int i=100;
    while(i>=1)
    {
    System.out.println(i);
    i--;
    }
    }
    } 
}
