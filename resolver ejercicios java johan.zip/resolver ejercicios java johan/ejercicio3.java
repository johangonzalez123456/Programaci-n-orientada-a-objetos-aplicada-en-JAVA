public class ejercicio3 {
    /*
* Ejercicios básicos java con estructura iterativa o repetitiva
* Mostrar los números del 1 al 100 utilizando un bucle for
*/
public class Repetitiva1_3 {
    public static void main(String[] args) {
    System.out.println("Numeros del 1 al 100: ");
    for(int i = 1; i<=100;i++)
    System.out.println(i);
    }
    }
}
